package Punto3;

import java.util.*;

public class Grafo {

    private Map<Integer, ArrayList<Integer>> adyacencia;

    public Grafo() {
        adyacencia = new HashMap<>();
    }

    public void agregarArista (int origen, int destino) {
        adyacencia.putIfAbsent(origen, new ArrayList<>());
        adyacencia.get(origen).add(destino);
        adyacencia.putIfAbsent(destino, new ArrayList<>());
    }

    public List<Integer> obtenerVerticesIniciales() {
        Set tieneEntrantes = new HashSet<>();
        List<Integer> iniciales = new ArrayList<>();

        for (List<Integer> vecinos : adyacencia.values()) {
            tieneEntrantes.addAll(vecinos);
        }

        for (Integer vertice : adyacencia.keySet()) {
            if (!tieneEntrantes.contains(vertice)) {
                iniciales.add(vertice);
            }
        }
        return iniciales;
    }

    public List<Integer> obtenerVerticesFinales(){
        List<Integer> finales= new ArrayList<>();

        for (Map.Entry<Integer, ArrayList<Integer>> entry : adyacencia.entrySet()) {
            if (entry.getValue().isEmpty()){
                finales.add(entry.getKey());
            }
        }
        return finales;
    }
}
