package Punto3;

import java.util.List;

public class GrafoTest {
    public static void main(String[] args) {
        // Crear una instancia del grafo
        Grafo grafo = new Grafo();

        // Insertar aristas
        grafo.agregarArista(1, 2);
        grafo.agregarArista(1, 3);
        grafo.agregarArista(3, 4);
        grafo.agregarArista(2, 5);
        grafo.agregarArista(4, 5);
        grafo.agregarArista(5, 6);

        // Probar el método obtenerVerticesIniciales
        List<Integer> iniciales = grafo.obtenerVerticesIniciales();
        System.out.println("Vértices iniciales: " + iniciales);  // Debería imprimir [1]

        // Probar el método obtenerVerticesFinales
        List<Integer> finales = grafo.obtenerVerticesFinales();
        System.out.println("Vértices finales: " + finales);  // Debería imprimir [6]
    }
}
/*
Costo en espacio:
La representación de la lista de adyacencia ocupa O(V + E), donde V es el número de vértices y E es el número de aristas.
Los conjuntos y listas auxiliares utilizados para almacenar los vértices iniciales y finales ocupan O(V).
Costo en tiempo:
El método para encontrar los vértices iniciales tiene un costo de O(V + E),
ya que recorremos todas las aristas para identificar los vértices que tienen aristas entrantes.
El método para encontrar los vértices finales tiene un costo de O(V),
ya que solo revisamos las listas de adyacencia para ver si están vacías.
 */
