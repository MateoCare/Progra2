package Punto1;

import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

public class PilaComparador {

    public static boolean pilasIguales(Stack<Integer> pila, Stack<Integer> pila2) {

        Set<Integer> conjunto1 = new HashSet<>(pila);
        Set<Integer> conjunto2 = new HashSet<>(pila2);

        return conjunto1.equals(conjunto2);
    }
}
