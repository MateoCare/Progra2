package Punto1;

import java.util.Stack;

public class Main {

    public static void main(String[] args) {

        Stack<Integer> pila = new Stack<>();
        Stack<Integer> pila2 = new Stack<>();

        System.out.println("Lista vacia: " + pila);
        System.out.println("Esta vacia? " + pila.isEmpty());

        pila.push(1);
        pila.push(2);
        pila.push(3);
        pila.push(4);

        pila2.push(4);
        pila2.push(3);
        pila2.push(2);
        pila2.push(1);

        System.out.println("Contenido de pila1: " + pila);
        System.out.println("Contenido de pila2: " + pila2);

        boolean pilasIguales= PilaComparador.pilasIguales(pila, pila2);
        System.out.println("Pilas iguales: " + pilasIguales);

        /*Estrategia:
        Extraer los elementos de ambas pilas en una estructura que permita el procesamiento sin modificar las
        pilas originales (por ejemplo, utilizando una copia de las pilas).
        Usar una estructura de conjunto (Set) que almacene elementos sin repeticiones y sin importar el orden.
        Insertar todos los elementos de cada pila en un conjunto.
        Comparar ambos conjuntos. Si contienen los mismos elementos, las pilas son equivalentes,
        sin importar el orden ni las repeticiones.

        Calculo del costo y explicacion:
        Espacio: El uso de dos conjuntos adicionales para almacenar los elementos de las pilas representa un espacio
        de O(n + m), donde n es el tamaño de la primera pila y m el de la segunda.
        Tiempo: El costo temporal es O(n + m), ya que se debe recorrer ambas pilas para insertar los elementos en los
        conjuntos y luego compararlos.

         */
    }
}
