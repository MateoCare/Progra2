package Punto2;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Nodo raiz = new Nodo(10);
        raiz.izquierdo = new Nodo(5);
        raiz.izquierdo.derecho = new Nodo(6);
        raiz.izquierdo.derecho.derecho = new Nodo(7);
        raiz.derecho = new Nodo(20);
        raiz.derecho.izquierdo = new Nodo(15);

        int altura = ArbolBinario.calcularAltura(raiz);
        System.out.println("La altura del árbol es: " + altura);

        /*Caso base: Si el árbol está vacío (es decir, no hay nodos), su altura es -1. En algunas implementaciones,
        se puede decir que la altura es 0, pero en general, -1 indica que no hay niveles en un árbol vacío.
        Caso recursivo:
        Si el árbol no está vacío, se calcula la altura de los subárboles izquierdo y derecho.
        La altura del árbol será la mayor de las alturas de sus subárboles más 1 (porque se cuenta también el nodo raíz).
        Es decir, el algoritmo recorre el árbol en profundidad hasta alcanzar una hoja, y luego retrocede sumando la
        mayor altura de los subárboles.*/

    }
}