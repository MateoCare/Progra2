package Punto2;

public class ArbolBinario {

    // Método que calcula la altura de un árbol binario de búsqueda
    public static int calcularAltura(Nodo raiz) {
        // Si el árbol está vacío, la altura es -1
        if (raiz == null) {
            return -1;
        }

        // Calcula la altura de los subárboles izquierdo y derecho
        int alturaIzquierda = calcularAltura(raiz.izquierdo);
        int alturaDerecha = calcularAltura(raiz.derecho);

        // La altura del árbol es el máximo entre las dos alturas + 1
        return Math.max(alturaIzquierda, alturaDerecha) + 1;
    }
}