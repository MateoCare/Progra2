package Punto4;

public class PilaTest {
    public static void main(String[] args) {
        PilaLimitadaTDA pila = new PilaLimitada();
        pila.inicializarPila(3);  // Límite de 3 elementos

        pila.apilar(1);
        pila.apilar(2);
        pila.apilar(3);
        System.out.println("Tope de la pila: " + pila.tope());  // Debería imprimir 3

        pila.apilar(4);  // Esto elimina el 1 y apila el 4
        System.out.println("Tope de la pila después de apilar 4: " + pila.tope());  // Debería imprimir 4

        pila.desapilar();
        System.out.println("Tope de la pila después de desapilar: " + pila.tope());  // Debería imprimir 3

        pila.apilar(5);
        pila.apilar(6);  // Ahora la pila debería contener [4, 5, 6]
        System.out.println("Tope de la pila después de apilar 6: " + pila.tope());  // Debería imprimir 6

    }
}
/*
InicializarPila: O(1) ya que solo se inicializan las variables.
Apilar: O(1) en el mejor caso, ya que agregar a una lista enlazada es O(1). Sin embargo,
cuando se debe eliminar el primer elemento, es O(n) porque implica mover todos los elementos de la lista.
Desapilar: O(1) porque eliminar el último elemento de una lista enlazada es directo.
PilaVacia: O(1) ya que simplemente revisa si la lista está vacía.
Tope: O(1), ya que obtener el último elemento de una lista enlazada es directo.
 */
