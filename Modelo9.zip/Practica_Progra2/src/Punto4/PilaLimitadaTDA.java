package Punto4;

public interface PilaLimitadaTDA {

    void inicializarPila(int limite);
    void apilar(int elemento);
    void desapilar();
    boolean pilaVacia();
    int tope();
}
