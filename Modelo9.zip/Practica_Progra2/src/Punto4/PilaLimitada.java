package Punto4;

import java.util.LinkedList;

public class PilaLimitada implements PilaLimitadaTDA {

    private LinkedList<Integer> pila;
    private int limite;

    @Override
    public void inicializarPila(int limite) {
        if (limite <= 0){
            throw new IllegalArgumentException("Limite no valido");
        }
        this.limite = limite;
        pila = new LinkedList<Integer>();
    }

    @Override
    public void apilar(int elemento) {

        if (pila.size() == limite){
            pila.removeFirst();
        }
        pila.addLast(elemento);
    }

    @Override
    public void desapilar() {

        if (pilaVacia()){
            throw new IllegalArgumentException("Pila vacia");
        }
        pila.removeLast();
    }

    @Override
    public boolean pilaVacia() {
        return pila.isEmpty();
    }

    @Override
    public int tope() {
        if (pilaVacia()){
            throw new IllegalArgumentException("Pila vacia");
        }
        return pila.getLast();
    }
}
